/** Automatically generated file. DO NOT MODIFY */
package io.vov.vitamio;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}