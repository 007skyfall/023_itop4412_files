VitamioDemo
===========

Demo of Vitamio for Android