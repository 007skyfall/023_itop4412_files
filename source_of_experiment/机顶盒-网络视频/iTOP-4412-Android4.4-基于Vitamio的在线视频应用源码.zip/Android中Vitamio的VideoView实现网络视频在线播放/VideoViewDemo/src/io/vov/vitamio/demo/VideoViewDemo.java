/*
 * Copyright (C) 2012 YIXIA.COM
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package io.vov.vitamio.demo;

import java.util.logging.Logger;

import io.vov.vitamio.MediaPlayer;
import io.vov.vitamio.MediaPlayer.OnCompletionListener;
import io.vov.vitamio.MediaPlayer.OnErrorListener;
import io.vov.vitamio.MediaPlayer.OnInfoListener;
import io.vov.vitamio.MediaPlayer.OnPreparedListener;
import io.vov.vitamio.Vitamio;
import io.vov.vitamio.widget.MediaController;
import io.vov.vitamio.widget.VideoView;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class VideoViewDemo extends Activity {

	private VideoView mVideoView;

	@Override
	public void onCreate(Bundle icicle) {
		super.onCreate(icicle);
		Vitamio.isInitialized(getApplicationContext());
		setContentView(R.layout.videoview);
		playfunction();
		myOnClick();


	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		if (mVideoView != null)
			mVideoView.setVideoLayout(VideoView.VIDEO_LAYOUT_SCALE, 0);
		super.onConfigurationChanged(newConfig);
	}
    /**
     * ������Ƶ
     */
	void playfunction() {
		String path = "";
//		path = "http://gslb.miaopai.com/stream/oxX3t3Vm5XPHKUeTS-zbXA__.mp4";
		path = "http://gslb.miaopai.com/stream/oxX3t3Vm5XPHKUeTS-zbXA__.mp4";
		path="http://bsyqncdn.miaopai.com/stream/5k4BMYqDHxv0oRvh4rzFV5TfbnVfCWcE.mp4?ssig=a3d725994a54d988471110a055653975&time_stamp=1498896861243&f=/5k4BMYqDHxv0oRvh4rzFV5TfbnVfCWcE.mp4?";
		
		mVideoView = (VideoView) findViewById(R.id.surface_view);
		if (path == "") {
			// Tell the user to provide a media file URL/path.
			Toast.makeText(VideoViewDemo.this, "·������", Toast.LENGTH_LONG)
					.show();
			return;
		} else {
			mVideoView.setVideoPath(path);
			mVideoView.setMediaController(new MediaController(this));
			mVideoView.requestFocus();

			mVideoView
					.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
						@Override
						public void onPrepared(MediaPlayer mediaPlayer) {
							// optional need Vitamio 4.0
							mediaPlayer.setPlaybackSpeed(1.0f);
						}
					});
		}
	}
	/**
	 * ����
	 */
	private void myOnClick(){
		//����һ�¼�����������ɵļ���������׼���õļ��������ų���ļ���
		
		mVideoView.setOnPreparedListener(new OnPreparedListener() {
		
					@Override
					public void onPrepared(MediaPlayer mp) {
						// TODO Auto-generated method stub
						//��ʼ����
						progressDialog2.dismiss();
					}
				});
		
		mVideoView.setOnCompletionListener(new OnCompletionListener() {
		
					@Override
					public void onCompletion(MediaPlayer mp) {
						Toast.makeText(getApplicationContext(), "��Ƶ���������", Toast.LENGTH_SHORT).show();
						finish();//�˳�������
					}
				});
		
		mVideoView.setOnErrorListener(new OnErrorListener() {
		
					@Override
					public boolean onError(MediaPlayer mp, int what, int extra) {
						Toast.makeText(getApplicationContext(), "��Ƶ���ų�����",  Toast.LENGTH_SHORT).show();
						return true;
					}
				});
/**		
 * ��������
 * 
 */
		mVideoView.setOnInfoListener(new OnInfoListener() {
		    @Override
		    public boolean onInfo(MediaPlayer mp, int what, int extra) {
		      switch (what) {
		      case MediaPlayer.MEDIA_INFO_BUFFERING_START:
		        if (mVideoView.isPlaying()) {
		          mVideoView.pause();
		         
		        }
		        break;
		      case MediaPlayer.MEDIA_INFO_BUFFERING_END:
		        mVideoView.start();
		       
		        break;
		      case MediaPlayer.MEDIA_INFO_DOWNLOAD_RATE_CHANGED:
		      
		        break;
		      }
		      return true;
		    }
				
			
		});
		mVideoView.setBufferSize(1024);
	}
	
//	��ʾ�����չʾdailog
	ProgressDialog progressDialog2=null;
	@Override
	protected void onResume() {
		super.onResume();
		progressDialog2=new ProgressDialog(VideoViewDemo.this);
		progressDialog2.setMessage("���������С�����");
		progressDialog2.setCancelable(true);
		progressDialog2.show();//�Ի�����ʾ
			
	}
	 

}
