package real.client.com;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class RealclientActivity extends Activity
{
  /* 鏈嶅姟鍣ㄥ湴鍧� */
  private final String SERVER_HOST_IP = "192.168.1.109";

  /* 鏈嶅姟鍣ㄧ鍙� */
  private final int SERVER_HOST_PORT = 9500;
  
  private Button btnConnect;
//  private Button btnSend;
//  private EditText editSend;
  private Socket socket;
  private PrintStream output;
  
  private Button btnLED2_ON;
  private Button btnLED2_OFF;
  private Button btnLED3_ON;
  private Button btnLED3_OFF;
  private Button btnBUZZER_ON;
  private Button btnBUZZER_OFF;


  public void toastText(String message)
  {
    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
  }

  public void handleException(Exception e, String prefix)
  {
    e.printStackTrace();
    toastText(prefix + e.toString());
  }

  /** Called when the activity is first created. */
  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.main);

    initView();

    btnConnect.setOnClickListener(new Button.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        initClientSocket();
      }
    });
 /**   
    btnSend.setOnClickListener(new Button.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        sendMessage(editSend.getText().toString());
      }
    });
   */ 
    
    btnLED2_ON.setOnClickListener(new Button.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        sendMessage("l2 on");
      }
    });
    
    btnLED2_OFF.setOnClickListener(new Button.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        sendMessage("l2 off");
      }
    });
    
    btnLED3_ON.setOnClickListener(new Button.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        sendMessage("l3 on");
      }
    });
    
    btnLED3_OFF.setOnClickListener(new Button.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        sendMessage("l3 off");
      }
    });
    
    btnBUZZER_ON.setOnClickListener(new Button.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        sendMessage("buz on");
      }
    });
    
    btnBUZZER_OFF.setOnClickListener(new Button.OnClickListener()
    {
      @Override
      public void onClick(View v)
      {
        sendMessage("buz off");
      }
    });
    
  }
  
  public void initView()
  {
    btnConnect = (Button)findViewById(R.id.btnConnect);
//    btnSend = (Button)findViewById(R.id.btnSend);
//    editSend = (EditText)findViewById(R.id.sendMsg);
    btnLED2_ON = (Button)findViewById(R.id.btnLED2_ON);
    btnLED2_OFF = (Button)findViewById(R.id.btnLED2_OFF);
    btnLED3_ON = (Button)findViewById(R.id.btnLED3_ON);
    btnLED3_OFF = (Button)findViewById(R.id.btnLED3_OFF);
    btnBUZZER_ON = (Button)findViewById(R.id.btnBUZZER_ON);
    btnBUZZER_OFF = (Button)findViewById(R.id.btnBUZZER_OFF);
    

//    btnSend.setEnabled(false);
//    editSend.setEnabled(false);
    btnLED2_ON.setEnabled(false);
    btnLED2_OFF.setEnabled(false);
    btnLED3_ON.setEnabled(false);
    btnLED3_OFF.setEnabled(false);
    btnBUZZER_ON.setEnabled(false);
    btnBUZZER_OFF.setEnabled(false);
  }

  public void closeSocket()
  {
    try
    {
      output.close();
      socket.close();
	}
    catch (IOException e)
    {
      handleException(e, "close exception: ");
	}
  }
  
  private void initClientSocket()
  {
    try
    {
      /* 杩炴帴鏈嶅姟鍣� */
      socket = new Socket(SERVER_HOST_IP, SERVER_HOST_PORT);

      /* 鑾峰彇杈撳嚭娴� */
      output = new PrintStream(socket.getOutputStream(), true, "utf-8");
      
      btnConnect.setEnabled(false);
//      editSend.setEnabled(true);
//      btnSend.setEnabled(true);
      btnLED2_ON.setEnabled(true);
      btnLED2_OFF.setEnabled(true);
      btnLED3_ON.setEnabled(true);
      btnLED3_OFF.setEnabled(true);
      btnBUZZER_ON.setEnabled(true);
      btnBUZZER_OFF.setEnabled(true);
    }
    catch (UnknownHostException e)
    {
      handleException(e, "unknown host exception: " + e.toString());
    }
    catch (IOException e)
    {
      handleException(e, "io exception: " + e.toString());
    }
  }
  
  private void sendMessage(String msg)
  {
    output.print(msg);
  }
}