/** Automatically generated file. DO NOT MODIFY */
package real.client.com;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}