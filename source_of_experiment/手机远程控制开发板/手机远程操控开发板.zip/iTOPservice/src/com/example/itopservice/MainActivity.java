package com.example.itopservice;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

class buzzer {
	public native int       Open();
    public native int       Close();
    public native int       Ioctl(int num, int en);
}

class led {
	public native int       Open();
    public native int       Close();
    public native int       Ioctl(int num, int en);
}


public class MainActivity extends Activity {
	static {
		System.loadLibrary("led");
	}
	
private Button btnStart;
public Thread  newThread;
int flag=0;

buzzer buzzer = new buzzer();
led led = new led();
	 
 public void toastText(String message)
  {
    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
  }
 
 public void handleException(Exception e, String prefix)
 {
   e.printStackTrace();
   toastText(prefix + e.toString());
 }
 

	@Override
protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		initView();

		buzzer.Open();
		led.Open();
		 
		btnStart.setOnClickListener(new Button.OnClickListener()
	    {
	      @Override
	      public void onClick(View v)
	      { 
	    	  if(flag==0){
	    	  flag+=1;
	    	  initServiceSocket();
	      }
	       
	      }
	    });
	}
	
 public void initView(){
	 
	 btnStart = (Button)findViewById(R.id.start);
  }

 
 private void initServiceSocket()
 {
	 Log.i("abc","inital over");
	 newThread = new Thread(new Runnable() {
		 
	 @Override
	 public void run() { 
	        InputStream input=null;  
	        Socket  socket =null;
	        
	        String BUZZER_ON="buz on";
	        String BUZZER_OFF="buz off";
	        String LED2_ON="l2 on";
	        String LED2_OFF="l2 off";
	        String LED3_ON="l3 on";
	        String LED3_OFF="l3 off";
		    	try
	    		   {
	    			 //����˼���9500�˿�
	    		       ServerSocket s = new ServerSocket(9500);
	    		       socket= s.accept();   
	    		       Log.i("abc","connect succeed"); 
	    	/**           
	    	           while((length=input.read(buffer))!=-1)
	    	           {
	    	        	   sb.append(new String(buffer,0,length));
	    	        	   //������ǰѴ���������յ�����ƴ������
	    	        	  //�ѵ���������ѭ���ˣ�
	    	        	   
	    	           }
	    	           
	    	           String result=sb.toString();
	    	           Log.i("abc",result);
	    	           if(result.equals(BUZZER_ON)){
	    	        	   //���������������ַ������
	    	        	   Log.i("abc","buzzer is ready");
	    	        	   buzzer.Ioctl(0, 1);
	    	           }
	    	            
	    	   */    
	     	           while(true){
	    	   
	     	        	  input = socket.getInputStream(); 
	     		   //     input=new FileInputStream(new String("/data/abc.txt"));
	     		    	  StringBuilder sb=new StringBuilder();
	     		    	  byte [] buffer=new byte[1024];
	     		    	  int length=0;
	     		    	  length=input.read(buffer);
	     		    	  sb.append(new String(buffer,0,length));
	     		    	       
	    	        	 //��������
	    	        	   if(sb.toString().equals(BUZZER_ON)){
	    	        		   Log.i("abc",sb.toString());
		    	        	   buzzer.Ioctl(0, 1);
	    	        	   }
	    	        	   
	    	        	  //��������
	    	        	   if(sb.toString().equals(BUZZER_OFF)){
	    	        		   Log.i("abc",sb.toString());
		    	        	   buzzer.Ioctl(0, 0);
	    	        	   }
	    	        	   
	    	        	 //led2��
	    	        	   if(sb.toString().equals(LED2_ON)){
	    	        		   Log.i("abc",sb.toString());
		    	        	   led.Ioctl(0, 1);
	    	        	   }
	    	        	   
	    	        	  //led2��
	    	        	   if(sb.toString().equals(LED2_OFF)){
	    	        		   Log.i("abc",sb.toString());
		    	        	   led.Ioctl(0, 0);
	    	        	   }
	    	        	   
	    	        	 //led3��
	    	        	   if(sb.toString().equals(LED3_ON)){
	    	        		   Log.i("abc",sb.toString());
		    	        	   led.Ioctl(1, 1);
	    	        	   }
	    	        	   
	    	        	  //led3��
	    	        	   if(sb.toString().equals(LED3_OFF)){
	    	        		   Log.i("abc",sb.toString());
		    	        	   led.Ioctl(1, 0);
	    	        	   }
	    	        	   	        	   
	    	        	   }
     
	    		   }
	    		   catch (UnknownHostException e)
	    		   {
	    		     handleException(e, "unknown host exception: " + e.toString());
	    		   }
	    		   catch (IOException e)
	    		   {
	    		     handleException(e, "io exception: " + e.toString());
	    		   } 
		    		finally{
		    			
		    			try {
		    				if(null!=input){
		    					
		    					input.close();
		    				}
		    				
		    					if(null!=socket){
		    						
		    						socket.close(); 
		    					}		
						} 
						catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}    
		    		}
		    	
		            }
		    
		        });
	 
		    newThread.start(); //�����߳�
 }
 
	
}
